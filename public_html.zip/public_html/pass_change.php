<?PHP
session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: Destory.php");
	exit;
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
<title>おしらせ</title>
<style type="text/css">
.auto-style1 {
	text-align: right;
}
.auto-style2 {
	text-align: center;
	background-color: #99FF99;
	font-size: x-large;
	font-family: HG丸ｺﾞｼｯｸM-PRO;
}
.auto-style3 {
	font-size: large;
}
.auto-style4 {
	text-align: center;
}
nav{
	width: 100%; /*横幅の指定*/;
	border-top: 1px solid blue;
/*上部の線の色を指定*/border-bottom: 1px solid blue;
/*下部の線の色を指定*/margin-bottom: 1px; /**/;
	overflow: hidden;   /*おまじない*/
	margin-top: 0px;
}
nav ul{
    width: 125%; /*横幅の指定*/
    list-style-type: none;
}
nav li{
    <?PHP
	if($_SESSION["POWER"]==3){
    	echo 'width: 12%;';
    }
	else{
		echo 'width: 10.5%;';
	}
?>/*横幅の指定（線の分をマイナスする）*/
    border-left: 1px solid blue;  /*線を描く*/
    text-align: center; /*文字を中央に*/
    float: left;    /*左から並べる*/
}
nav li:last-child{
    border-right: 1px solid blue; /*li要素の最後の物は右側に線を描く*/
}
nav a{
    display: block; /*1つのli全体にリンクを有効にする*/
    text-decoration: none;  /*ブラウザ標準のリンク装飾をオフに*/
    color:#313131;  /*文字色の変更*/
    font-size: 110%;    /*フォントサイズの指定*/
    letter-spacing: 5px;    /*文字と文字の間隔をあける*/
    font-weight: 300;   /*文字の太さを調整*/
    line-height: 25px;  /*行間の指定（ナビボタンの高さ指定）*/
}
nav a:hover{
	background-color: blue;   /*背景色の指定*/
	color: #fff; /*文字色の変更*/;
	transition: 0.25s;   /*ホバー時の動きをなめらかにする*/
}
h2 {
	padding: .75em 1em;
	border: 1px solid #ccc;
	border-top: 3px solid #3498db;
	background: -webkit-linear-gradient(top, #fff 0%, #f0f0f0 100%);
	background: linear-gradient(to bottom, #fff 0%, #f0f0f0 100%);
	box-shadow: 0 -1px 0 rgba(255, 255, 255, 1) inset;
}</style>
</head>
<body>
<div class="auto-style1">
<?PHP
	if($_SESSION['POWER']==3){
		echo 'ID:'.$_SESSION["USERID"].'/ようこそ、'.$_SESSION["USERName"].'さん！';
	}
	else{
		echo '区分：';
		if($_SESSION['POWER']==1) echo '教員';
		else echo 'SA';
		echo '　/ID:'.$_SESSION["USERID"].'　/ようこそ、'.$_SESSION["USERName"].'さん！';
	}
?>
</div>
<nav><ul><li>
<?PHP
	if($_SESSION["POWER"]==3){
		echo '<a href="https://www.youtube.com/channel/UCOLHDVyHEmX9m-0bsocEFzA" target="_blank">解説動画</a>';
	}
	else{
		echo '<a href="FAQ_itiran.php">質問リスト</a>';
	}
?></li>
<?PHP
	if($_SESSION['POWER']=='1'){
		echo '<li><a href="classinsert.php">クラスの追加</a></li>';
	}
	else if($_SESSION['POWER']=='2'){
		print '<li>　</li>';
	}

	if($_SESSION['POWER']=='1'){
		echo '<li><a href="userinsert.php">ユーザーの追加</a></li>';
		echo '<li><a href="notifications.php">お知らせ設定</a></li>';
	}
	else if($_SESSION['POWER']=='2'){
		print '<li>　</li><li> </li>';
	}
	if($_SESSION['POWER']=='3'){
		echo '<li><a href="faq.php?KNo=">質問</a></li>';
	}
?>
<li><a href="pass_change.php">パスワード変更</a></li>
<li><?PHP
	if($_SESSION["POWER"]==3){
		echo '<a href="menu.php">';
	}
	else{
		echo '<a href="menu_tr.php">';
	}
?>もどる</a></li>
<?PHP
if($_SESSION['POWER']=='3') echo '<li><a href="codeview.php">コード表示</a></li>';
?>
<li><a href="Destory.php">ログアウト</a></li>
</ul>
</nav>
<h2>おしらせ</h2>
<center>
<p>
ただいま、パスワードの変更を【初回ログイン時】にのみ限定させていただいております。<br/>
パスワードの変更を希望する方は、このシステム管理者まで問い合わせください。
</p>

</center>
</body>
</html>
