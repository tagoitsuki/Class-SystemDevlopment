#!/bin/bash

#expect -c "
#spawn su - tto
#expect \"パスワード: \"
#spawn \"kambayashi\n\"
#expect /"[Oh My Zsh] Would you like to check for updates? [Y/n]: /"
#spawn \"n\n\"
#expect \"$\"
#exit 0;
#"

compiler=gcc

#usage="usage: $0 [FILE] [ARGUMENTS]"
usage="usage: ${0} [FILE] [USERID] [KADAINO]"
if [ $# = 2 ]; then
  echo "${usage}" >&2
  exit
fi

# 実行ファイルの出力先ディレクトリ
out_dir=/home/tto/public_html/kadai/complete_box/${2}/${3}

install -m 0777 ${out_dir}/${1} ${out_dir}/${3}.cpp

# 第一引数をソースファイルとする
source_file=${1}
userid=${2}
kadai_no=${3}
shift

# ファイルの存在チェック
if [ ! -e ${source_file} ]; then
  echo "file does not exist." >&2
  exit 1
fi

# 出力ファイルのパスを設定
filename=$(basename ${source_file})
out=${out_dir}/${filename%.*}

# 拡張子をもとにコンパイラを設定
extension=${filename##*.}

if [ ${extension} = "cpp" ]; then
  compiler=g++
fi


# 前回コンパイル時よりソースファイルが更新されていなければコンパイルしない
if [ -e ${out} ] && [ ${out} -nt ${source_file} ]; then
  echo "${out} is up to date." >&2
else

  # コンパイル
  echo "${compiler} ${1} -o ${out}" >&2
  ${compiler} ${source_file} -o ${out}
  # コンパイルエラー時は終了
  if [ ${?} != 0 ]; then
    echo "failed to compile." >&2
    exit 1
  fi
fi

# 実行
echo "${out} ${*}" >&2
${out} ${*}
echo "exit status: ${?}" >&2
