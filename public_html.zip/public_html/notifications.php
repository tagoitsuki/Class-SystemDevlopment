<?PHP
include 'Server.php';
$Server = new Server();

session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: Destory.php");
	exit;
}
?>
<?PHP
	$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
	if($mysqli->connect_error){
		//CONNECT FAILURE
		echo '<strong>▼Notice</strong><br/>CONNECT FAILURED';
	}
	else{
		$mysqli->set_charset("utf8");
	}
	$classno = $_SESSION['CLASS'];
	$sql = "SELECT * FROM class WHERE id_class ='".$classno."'";
	$result = $mysqli->query($sql);
	if(!$result){
		echo '<strong>▼Notice</strong><br/>Query is FAILURED'. $mysqli_error;
		exit();
	}
	while ($row = $result->fetch_assoc()){
		$classname = $row['class_name'];
	}
	
	if($classno=="1"){
		$PATH2DEB = "notif_PBL.txt";
	}
	else if($classno=="2"){
		$PATH2DEB = "notif_Media.txt";
	}
	else if($classno=="3"){
		$PATH2DEB = "notif_JE1.txt";
	}
	else if($classno=="4"){
		$PATH2DEB = "notif_JE2.txt";
	}
	
	echo 't1'.$PATH2DEB;
	
if(isset($_GET["save"])){
	echo 'a';
	$text = htmlspecialchars( $_GET["notif"] );
	echo 't2';
	if($text==NULL){
		$text = "お知らせはありません。";
	}
	echo 't3';
	$text = html_entity_decode($text, ENT_QUOTES);
	if($result = file_put_contents($PATH2DEB, $text)){
		echo 't4';
		header("Location: menu_tr.php");
		exit;
	}
	else{
		echo '書き込み失敗';
	}
}
echo 't5';
?>
<!DOCTYPE html>
<html>
<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
<title>
<?PHP
	echo $classname."クラスのお知らせ設定";
?>
</title>
</head>
<body>
<div><strong>お知らせ設定</strong></div>
<p>ログイン画面に表示されるお知らせ欄に《クラスごとに》掲載することができます。個別に連絡をする目的での利用は避けてください。</p>
<pre>担当クラス名：<?PHP echo $classname;?></pre>
<pre>以前の記述内容：</pre>
<?PHP
	$fp = fopen($PATH2DEB, 'r');
	
	// whileで行末までループ処理
	while (!feof($fp)) {
		// fgetsでファイルを読み込み、変数に格納
		$txt = fgets($fp);
		// ファイルを読み込んだ変数を出力
		echo $txt.'<br>';
	}
	// fcloseでファイルを閉じる
	fclose($fp);
?>
<pre>今回表示する内容：</pre>
<form>
<textarea name="notif" cols="80" rows="4" placeholder="未入力の場合は「お知らせはありません」と表示されます。">
</textarea><br/>
<input type="submit" name="save" action="notifications.php" value="保存"/>
</form>
<a href="menu_tr.php">戻る</a>
</body>
</html>