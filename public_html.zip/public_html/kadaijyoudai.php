﻿<?PHP
	include 'Server.php';

	function kadaijyoudai($no){
		kadaijyoudaiSPR($no);
	}
	function kadaijyoudaiSPR($no){
		$Server = new Server();
		$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
		if($mysqli->connect_error){
			exit;
		}
		else{
			$mysqli->set_charset("utf8");
		}
		$sql = "SELECT joutai FROM teisyutsu WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = '".$no."'";
		$result = $mysqli->query($sql);
		if(!$result){
			//echo '';
			exit();
		}
		while($row = $result->fetch_assoc()){
			$Js = $row["joutai"];
			if($Js=="0"){
				echo "採点待ち";
			}
			else if($Js=="-"){
				echo "未回答";
			}
			else if($Js=="×"){
				echo "再提出";
			}
			else if($Js=="○"){
				echo "合　格";
			}
		}
		$mysqli->close();
	}
	function kadaijyoudaiAUT($no){
		$Server = new Server();
		$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
		if($mysqli->connect_error){
			exit;
		}
		else{
			$mysqli->set_charset("utf8");
		}
		$sql = "SELECT joutai FROM teisyutsu WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = '".$no."'";
		$result = $mysqli->query($sql);
		if(!$result){
			//echo '';
			exit();
		}
		while($row = $result->fetch_assoc()){
			$Js = $row["joutai"];
			if($Js=="0"){
				echo "採点待ち";
			}
			else if($Js=="-"){
				echo "未回答";
			}
			else if($Js=="×"){
				echo "再提出";
			}
			else if($Js=="○"){
				echo "合　格";
			}
		}
		$mysqli->close();
	}
	function kadaiR1(){
		
		$Server = new Server();
		$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
		if($mysqli->connect_error){
			exit;
		}
		else{
			$mysqli->set_charset("utf8");
		}
		$sql = "SELECT joutai FROM teisyutsu WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = 'R1'";
		$result = $mysqli->query($sql);
		if(!$result){
			echo '';
			exit();
		}
		while($row = $result->fetch_assoc()){
			$Js = $row["joutai"];
			if($Js=="0"){
				echo "採点待ち";
			}
			else if($Js=="-"){
				echo "未回答";
			}
			else if($Js=="×"){
				echo "再提出";
			}
			else if($Js=="○"){
				echo "合　格";
			}
		}

		$mysqli->close();
	}
	function kadaiR2(){
		
		$Server = new Server();
		$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
		if($mysqli->connect_error){
			exit;
		}
		else{
			$mysqli->set_charset("utf8");
		}
		$sql = "SELECT joutai FROM teisyutsu WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = 'R2'";
		$result = $mysqli->query($sql);
		if(!$result){
			echo '';
			exit();
		}
		while($row = $result->fetch_assoc()){
			$Js = $row["joutai"];
			if($Js=="0"){
				echo "採点待ち";
			}
			else if($Js=="-"){
				echo "未回答";
			}
			else if($Js=="×"){
				echo "再提出";
			}
			else if($Js=="○"){
				echo "合　格";
			}
		}

		$mysqli->close();
	}
?>