﻿<?PHP
	include 'password.php';
	include 'Server.php';
	$ua = getenv('HTTP_USER_AGENT');
if (preg_match("/MSIE/", $ua)) {
    header("Location: BrowseIE.html");
}
if (preg_match("/Edge/", $ua)) {
    header("Location: BrowseEdge.html");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta content="ja" http-equiv="Content-Language" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
	<title>
		プログラミング支援システム ver.1
	</title>
	<style type="text/css">
		.auto-style3 {
			text-align: center;
		}
		.auto-style7 {
			font-size: xx-large;
			font-family: Verdana, Geneva, Tahoma, sans-serif;
			text-align: center;
		}
		.auto-style8 {
			font-size: small;
		}
	.auto-style9 {
		text-align: center;
		font-family: Verdana, Geneva, Tahoma, sans-serif;
		font-size: small;
	}
	</style>
</head>

<body lang="ja">
	<div class="auto-style7">
	<strong>プログラミング支援システム Ver.1.1.0</strong>
	<span class="auto-style8"><em><strong>Programming Support System Ver.1.1.0</strong></em></span>
	</div>
	<hr />
	<center>
		<div>
			<font color="#FF0000"><strong>ログイン成功してから【50分】経過すると勝手にログアウトします</strong></font>
			<br/>
		</div>
	</center>
	<form method="post" name="form">
		<fieldset name="Group1">
			<legend>
				ログイン
			</legend>
			<center><div>
			今日は
<?PHP
	echo date('Y')."年".date('m')."月".date('d')."日です。";
	if(date('m')=='04'||date('m')=='05'||date('m')=='06'||date('m')=='07'||date('m')=='08'){
		echo "今は春学期です。";
	}
	else{
		echo "今は秋学期です。";
	}
?>
			</div></center>
<?PHP
	// -*- coding: utf-8 -*-
	//header("Content-type: text/html; charset=UTF-8");
	//require_once 'password.php';
	session_start();
	if(isset($_POST['enter'])){
		$name = $_POST['ID1'];
		$Password = $_POST['password'];
		echo '<center>';
		if(empty($name)){
			echo '<font color="#FF0000">IDを入力してください.</font>';
		}
		else if(empty($Password)){
			echo '<font color="#FF0000">パスワードを入力してください.</font>';
		}
		echo '</center>';
		if(!empty($name)&& !empty($Password)){
			$Server = new Server();
			$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
			if($mysqli->connect_error){
				//CONNECT FAILURE
				echo "CONNECT FAILURE";
				exit();
			}
			else{
				$mysqli->set_charset("utf8");
			}
			
			// 入力値のサニタイズ
			$name = $mysqli->real_escape_string($_POST["ID1"]);
 
			$sql = "SELECT * FROM user WHERE id_user ='".$name . "'";
			$result = $mysqli->query($sql);
			if(!$result){
				echo 'Query is FAILURED.'. $mysqli_error;
				exit();
			}
			while ($row = $result->fetch_assoc()){
				$db_hashed_pwd = $row["psw"];
				$UName = $row["user_name"];
				$POWER = $row["power"];
				$CLASS = $row["fk_class"];
			}
			$mysqli->close();
			if($Password == $db_hashed_pwd){
				session_regenerate_id(true);
				$_SESSION["USERID"] = $name;
				$_SESSION["USERName"] = $UName;
				$_SESSION["POWER"] = $POWER;
				$_SESSION["CLASS"] = $CLASS;
				if($name==$Password){
					header("Location: defaultpasschange.php");
					exit;
				}
				else{
					$lifetime = 50 * 60;//50分のタイムアウトを設定しておけばおｋ？
					session_set_cookie_params($lifetime);
					if($POWER =='3'){
						header("Location: menu.php");
						exit;
					}
					else{
						header("Location: menu_tr.php");
						exit;
					}
				}
			}
			else{
				header("Location: loginerror.php");
			}
		}
		else{
		}
	}
?>
			<p class="auto-style3">User ID：
				<input type="text" name="ID1" id="ID1" size="20"/>
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Password：
				<input type="password" name="password" id="password"/>
			</p>
			<div class="auto-style3">
				<button style="submit" name="enter" id="enter">ログイン</button>
			</div>
		</fieldset>
	</form>
	<form method="post">
		<fieldset name="Group1">
			<legend>
				更新情報
			</legend>
			<div>
				Ver. 1.1.0 仮運用開始。
			</div>
		</fieldset>
	</form>
	<form method="post">
		<fieldset name="Group1">
			<legend>
				各クラスからのお知らせ
			</legend>
			<table border="1" width="100%">
				<tr><td>PBL演習室</td><td>
<?PHP
	$PATH2DEB = "notif_PBL.txt";
	$fp = fopen($PATH2DEB, 'r');
	
	// whileで行末までループ処理
	while (!feof($fp)) {
		// fgetsでファイルを読み込み、変数に格納
		$txt = fgets($fp);
		// ファイルを読み込んだ変数を出力
		echo $txt.'<br>';
	}
	// fcloseでファイルを閉じる
	fclose($fp);
?></td></tr>
				<tr><td>先進メディア教室</td><td>
<?PHP
	$PATH2DEB = "notif_Media.txt";
	$fp = fopen($PATH2DEB, 'r');
	
	// whileで行末までループ処理
	while (!feof($fp)) {
		// fgetsでファイルを読み込み、変数に格納
		$txt = fgets($fp);
		// ファイルを読み込んだ変数を出力
		echo $txt.'<br>';
	}
	// fcloseでファイルを閉じる
	fclose($fp);
?></td></tr>
				<tr><td>情報処理演習室１</td><td>
<?PHP
	$PATH2DEB = "notif_JE1.txt";
	$fp = fopen($PATH2DEB, 'r');
	
	// whileで行末までループ処理
	while (!feof($fp)) {
		// fgetsでファイルを読み込み、変数に格納
		$txt = fgets($fp);
		// ファイルを読み込んだ変数を出力
		echo $txt.'<br>';
	}
	// fcloseでファイルを閉じる
	fclose($fp);
?></td></tr>
				<tr><td>情報処理演習室２</td><td>
<?PHP
	$PATH2DEB = "notif_JE2.txt";
	$fp = fopen($PATH2DEB, 'r');
	
	// whileで行末までループ処理
	while (!feof($fp)) {
		// fgetsでファイルを読み込み、変数に格納
		$txt = fgets($fp);
		// ファイルを読み込んだ変数を出力
		echo $txt.'<br>';
	}
	// fcloseでファイルを閉じる
	fclose($fp);
?></td></tr>
			</table>
			<center>
			<p>
				<a href="source/AppOpenなどの設定方法.pdf" target="_blank">AppOpen,AppOpen2,BoxCieの設定方法はこちら（Win10）</a>
			</p>
			</center>
		</fieldset>
		</form>
	<hr>
	<footer class="auto-style9"><em><strong>COPYRIGHT(C)2017 データベース特攻隊　ALL RIGHTS RESERVED.</strong></em></footer>
</body>

</html>

