#!/bin/bash

${out_dir}/${kadai_no} <<EOF
34567
EOF