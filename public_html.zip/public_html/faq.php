﻿<?PHP
session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: Destory.php");
	exit;
}
?>
<?PHP
	include 'Server.php';
	$Server = new Server();
	
	$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
	
	if($mysqli->connect_error){
		//CONNECT FAILURE
		echo '<strong>▼Notice</strong><br/>CONNECT FAILURED';
	}
	else{
		$mysqli->set_charset("utf8");
	}
	if(isset($_POST['Abutton1'])){
		$sqlc = "SELECT * FROM kadai WHERE kadai_name='".$_POST['Text1']."'";
		$res = $mysqli->query($sqlc);
		if($res){
			while($row = $res->fetch_assoc()){
				$id = $row["id_kadai"];
			}
		}
		$sql = "UPDATE teisyutsu SET cmnt_user='".$_POST['TextArea1']."' WHERE fk_id_user='".$_SESSION['USERID']."' AND fk_id_kadai='".$id."'";
		$result = $mysqli->query($sql);
		if(!$result){
			echo '<strong>▼Notice</strong><br/>Query is FAILURED'. $mysqli_error;
			exit();
		}
		header("Location: faq_conp.php");
		exit();
	}
	
	if(isset($_GET['Abutton2'])){
		header("Location: menu.php");
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
	<title>質問フォーム</title>
	<style type="text/css">
.auto-style1 {
	text-align: right;
}
		.auto-style2 {
			text-align: right;
		}
	.auto-style3 {
	color: #FFFFFF;
	font-size: x-large;
	background-color: #0000FF;
}
nav{
	width: 100%; /*横幅の指定*/;
	border-top: 1px solid blue;
/*上部の線の色を指定*/border-bottom: 1px solid blue;
/*下部の線の色を指定*/margin-bottom: 1px; /**/;
	overflow: hidden;   /*おまじない*/
	margin-top: 0px;
}
nav ul{
    width: 125%; /*横幅の指定*/
    list-style-type: none;
}
nav li{
    	width: 12%; /*横幅の指定（線の分をマイナスする）*/
    border-left: 1px solid blue;  /*線を描く*/
    text-align: center; /*文字を中央に*/
    float: left;    /*左から並べる*/
}
nav li:last-child{
    border-right: 1px solid blue; /*li要素の最後の物は右側に線を描く*/
}
nav a{
    display: block; /*1つのli全体にリンクを有効にする*/
    text-decoration: none;  /*ブラウザ標準のリンク装飾をオフに*/
    color:#313131;  /*文字色の変更*/
    font-size: 110%;    /*フォントサイズの指定*/
    letter-spacing: 5px;    /*文字と文字の間隔をあける*/
    font-weight: 300;   /*文字の太さを調整*/
    line-height: 25px;  /*行間の指定（ナビボタンの高さ指定）*/
}
nav a:hover{
	background-color: blue;   /*背景色の指定*/
	color: #fff; /*文字色の変更*/;
	transition: 0.25s;   /*ホバー時の動きをなめらかにする*/
}
h2 {
	padding: .75em 1em;
	border: 1px solid #ccc;
	border-top: 3px solid #3498db;
	background: -webkit-linear-gradient(top, #fff 0%, #f0f0f0 100%);
	background: linear-gradient(to bottom, #fff 0%, #f0f0f0 100%);
	box-shadow: 0 -1px 0 rgba(255, 255, 255, 1) inset;
}
	</style>
	<script type="text/javascript">
	<!--
		function insertTab(o, e){
			var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
			if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey){
				var oS = o.scrollTop;
				if (o.setSelectionRange){
					var sS = o.selectionStart;
					var sE = o.selectionEnd;
					o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
					o.setSelectionRange(sS + 1, sS + 1);
					o.focus();
				}
				else if (o.createTextRange){
					document.selection.createRange().text = "\t";
					e.returnValue = false;
				}
				o.scrollTop = oS;
				if (e.preventDefault){
					e.preventDefault();
				}
				return false;
			}
			return true;
		}//-->
	</script>
</head>

<body>
<div class="auto-style1">
	ID:<?=htmlspecialchars($_SESSION["USERID"], ENT_QUOTES); ?>/ようこそ、<?=htmlspecialchars($_SESSION["USERName"], ENT_QUOTES); ?>さん！
</div>
<nav><ul>
	<li><a href="https://www.youtube.com/channel/UCOLHDVyHEmX9m-0bsocEFzA" target="_blank">解説動画</a></li>
	<li><?PHP
	if($_SESSION["POWER"]==3){
		echo '<a href="menu.php">';
	}
	else{
		echo '<a href="menu_tr.php">';
	}
?>もどる</a></li>
<li><a href="pass_change.php">パスワード変更</a></li>
<li><a href="show.php">情報表示</a></li>
<li><a href="codeview.php">コード表示</a></li>
<li><a href="Destory.php">ログアウト</a></li>
</ul>
</nav>
	<h2>質問フォーム</h2>
	<div>
		質問内容を入力してください。
		<form method="post">
			課題番号：<input name="Text1" type="text"
			<?PHP
				if($_GET['KNo']!=NULL) echo 'readonly="true" value="'.$_GET['KNo'].'"';
			?>/>
			<br />
		<br />
			<strong>質問内容：</strong><br/>
		<textarea cols="20" name="TextArea1" style="width: 100%; height: 200px; font-size: large;" onkeydown="insertTab(this, event);"></textarea>
			<div class="auto-style2">
				<button name="Abutton1" type="submit" action="faq.php">質問を送ります！</button>&nbsp;
				<button name="Abutton2" type="submit" action="faq.php">やっぱ投稿しない</button></div>
		</form>
	</div>
</body>
</html>
