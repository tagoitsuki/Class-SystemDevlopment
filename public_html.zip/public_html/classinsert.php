﻿<?PHP
	include 'Server.php';
	$Server = new Server();
?>
<link rel="stylesheet" href="style.css" type="text/css">

<html>
<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
<title>クラスの追加</title>
<style type="text/css">
#regi{float: left;}
#show{float: right; text-align: left;}
</style>
</head>
<body>
<div id="regi">
<form method="post" action="classinsert.php">
<input type="submit" name="return" value="教員用メニューに戻る"/>
<table><tr><td>教室ID</td><td><input type="text" name="num"></td></tr>
<tr><td>教室名</td><td><input type="text" name="class"></td></tr></table>
<input type="submit" name="exe" value="登録">
</form>
</div>
<?php
/*新対応済み*/
$server = $Server->url; //ホスト名。ポート番号指定の時は、"10.2.3.4:8809" のように指定する
$user   = $Server->user;    //ユーザー名
$passwd = $Server->dbpass;   //パスワード
$dbname = $Server->dbname;    //データベース名

	$link = new mysqli($server, $user, $passwd, $dbname);
	if ($link->connect_errno)
	{
		die("接続失敗\n");
	}
	if (version_compare(PHP_VERSION, '5.2.3') >= 0)
	{
		// PHP 5.2.3 以上で利用可能。こちらの使用を強く勧める。
		$result = mysqli_set_charset($link, "utf8");
	} else {
		$result = mysqli_query($link,"SET NAMES utf8");
	}
	if (!$result)
	{
		echo "charset変更失敗\n" . mysqli_error() . "\n終了\n";
		mysqli_close($link);
		exit(1);
	}
	if (!mysqli_select_db($link, $dbname))// DB選択
	{
		die("DB変更失敗\n" . mysqli_error() . "\n終了\n");
		mysqli_close($link);
		exit(1);
	}
	if((count($_POST) > 0)&&($_POST['num']!=NULL)&&($_POST['class']!=NULL)){
		$num = $_POST['num'];
		$name =$_POST['class'];
		$insert = "INSERT INTO class VALUES('$num','$name'); ";
		mysqli_query($link , $insert);
	}
	$result = mysqli_query($link, "SELECT * FROM class");// 	クエリ―設定
	if (!$result)
	{
		echo "クエリー失敗\n" . mysqli_error() . "\n終了\n";
		mysqli_close($link);
		exit(1);
	}
	echo "<div id=\"show\">";
if(isset($_POST['exe'])){
	while ($row = mysqli_fetch_object($result))
	{
		$i_c    = htmlspecialchars($row->id_class);
		$n_c    = htmlspecialchars($row->class_name);
		print nl2br("ID:" . $i_c . "\tClassName:" .$n_c ."\n") ;
	}
	mysqli_free_result($result);// メモリ解放
	mysqli_close($link);
}
if(isset($_POST['return'])){
	header("Location: menu_tr.php");
	exit;
}
else{
	
}
echo "</div></body></html>";
?>
