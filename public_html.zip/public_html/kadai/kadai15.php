﻿<?PHP
	include '../Server.php';
	$Server = new Server();
?>
<?PHP
session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: ../Destory.php");
	exit;
}
if(isset($_POST['runstart'])){
	$FPATH2Prg = '/home/tto/public_html/kadai/complete_box/'.$_SESSION['USERID'].'/15/15.txt';
	$text = htmlspecialchars( $_POST["TextArea1"] );
	echo 'PASS:'.$FPATH2Prg.'<br/>';
		
	if(!$fp = fopen($FPATH2Prg,'wb')){
		echo 'ファイルオープン失敗';
		exit();
	}
	$text = html_entity_decode($text, ENT_QUOTES);
	if($result = fwrite($fp, $text."\n")){
		fclose($fp);
		header("Location: ../compile_execute_result.php?no=15");
		exit();
	}
	else{
		echo '書き込み失敗';
	}
}
else if(isset($_POST['faq'])){
	header("Location: ../faq.php?KNo=15");
	exit();
}
else if(isset($_POST['throws'])){
	//提出時の動作
	$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
	if($mysqli->connect_error){
		//CONNECT FAILURE
		echo "<p>CONNECT FAILURE</p>";
	}
	else{
		$mysqli->set_charset("utf8");
	}
	$times=date('Y-m-d');
	$sql1 = "UPDATE teisyutsu SET joutai = '0' AND date='".$times."' WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = '15'";
	$result1 = $mysqli->query($sql1);
	if(!$result1){
		echo '<p>Query is FAILURED.</p>'. $mysqli_error;
		exit();
	}
	$sql2= "INSERT INTO teisyutsu (fk_id_user, fk_id_kadai, joutai) VALUES ('".$_SESSION['USERID']."', '16', '-')";
	$mysqli->query($sql2);
	$mysqli->close();
	header("Location: ../menu.php");
	exit;
}
else{
	
}
?>
<!DOCTYPE html>
<html>

<head>
	<meta content="ja" http-equiv="Content-Language" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<meta http-equiv="x-ua-compatible" content="IE=10">
	<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
	<title>
		課題15
	</title>
	<style type="text/css">
		.auto-style1 {
			text-align: right;
		}
		.auto-style2 {
			font-size: medium;
		}
		.auto-style5 {
			text-align: center;
		}
		.auto-style10 {
			text-align: left;
		}
		.auto-style11 {
			text-align: left;
			font-size: larger;
		}
		.auto-style12 {
			text-align: center;
			font-size: x-large;
			font-family: "Arial Black";
		}
		.auto-style13 {
			font-size: small;
		}
		.auto-style14 {
			text-decoration: underline;
		}
		.auto-style15 {
			margin-left: 40px;
		}
		.auto-style20{
			background-color: #66FFFF;
		}
		.auto-style21{
			width: 100%;
			height:400px;
			font-family: 'Courier New', Courier, monospace;
			font-size: large;
		}
		.auto-style22{
			 width: 100%;
			 height: 41px;
			 z-index: 1;
			 left: 15px;
			 top: 577px;
			 bottom: -69px;
		}
	</style>
	<script type="text/javascript">
	<!--
		function insertTab(o, e){
			var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
			if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey){
				var oS = o.scrollTop;
				if (o.setSelectionRange){
					var sS = o.selectionStart;
					var sE = o.selectionEnd;
					o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
					o.setSelectionRange(sS + 1, sS + 1);
					o.focus();
				}
				else if (o.createTextRange){
					document.selection.createRange().text = "\t";
					e.returnValue = false;
				}
				o.scrollTop = oS;
				if (e.preventDefault){
					e.preventDefault();
				}
				return false;
			}
			return true;
		}//-->
	</script>
</head>

<body>
	<div class="auto-style1">
		[Name:<?=htmlspecialchars($_SESSION["USERName"], ENT_QUOTES); ?>][<a href="../menu.php">Menu</a>]
	</div>
	<hr/>
	<div class="auto-style12">
		<strong>
			課題15:正三角形
			<br />
		</strong>
		<span class="auto-style13">
			キーワード：for文、二重の繰り返し
		</span>
	</div>
	<hr/>
	<form method="post">
		<div class="auto-style16" style="margin-bottom: 2em">
			<fieldset class="auto-style20" name="Group1" style="width: 90%">
				<legend class="auto-style11">
					<strong>
						課題の内容
					</strong>
				</legend>
				<div class="auto-style10">
					<p class="auto-style15">
						<strong>
							<span class="auto-style14">
								for文（教科書p.150）を使って、○を三角形に並べるプログラムを作成しなさい。
							</span>
						</strong>
					</p>
					<p class="auto-style15">
						&emsp;&emsp;ただし、i行目にj個（i+1個）、0～9行目まで並べる。<br />
						<span class="auto-style14">実行例：</span><br />
						&emsp;&emsp;○<br />
						&emsp;&emsp;○○<br />
						&emsp;&emsp;○○○<br />
						&emsp;&emsp;○○○○<br />
						&emsp;&emsp;○○○○○<br />
						&emsp;&emsp;○○○○○○<br />
						&emsp;&emsp;○○○○○○○<br />
						&emsp;&emsp;○○○○○○○○<br />
						&emsp;&emsp;○○○○○○○○○<br />
						&emsp;&emsp;○○○○○○○○○○<br />
						<br />
					</p>
				</div>
			</fieldset>
		</div>
	</form>
	<form method="post">
		<textarea class="auto-style21" name="TextArea1" tabindex="0" cols="20" rows="1" onkeydown="insertTab(this, event);">
#define _CRT_SECURE_NO_WARNINGS  // 余計な警告が出ないようにする
#include	<stdio.h>

int	main( void )
{
	int	i, j;

	//// 以下にfor文を使って、○を三角形に並べる（i行目にj個（i+1個）、0行目から
	//// 9行目まで並べる）プログラムを作成


	return 0;
}</textarea>
		<div class="auto-style22" id="layer1">
			<button class="auto-style2" name="faq" action="kadai15.php">質問</button>　
			<button class="auto-style2" name="runstart" action="kadai15.php">コンパイル・実行</button>　
			<button class="auto-style2" name="throws" action="kadai15.php">提出</button><br />
			<hr/>
			<p class="auto-style5">
				最終更新日：2016.04.01
			</p>
		</div>
	</form>
</body>
</html>
