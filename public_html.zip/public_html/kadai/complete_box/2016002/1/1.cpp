#define _CRT_SECURE_NO_WARNINGS  // 余計な警告が出ないようにする
#include	<stdio.h>

int	main( void )
{
	int	money;
	int	no;

	printf( "金額を入力してください > " );
	scanf( "%d", &money );

	//// 以下に金種計算を行うプログラムを作成する。
	printf("%d", money);
	
	return 0;
}
