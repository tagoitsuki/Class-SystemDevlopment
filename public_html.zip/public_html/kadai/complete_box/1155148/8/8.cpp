#define _CRT_SECURE_NO_WARNINGS  // 余計な警告が出ないようにする
#include	"stdio.h"

int	main( void )
{
	int	ans = 0;	// 和の値
	int	i;

	//// 以下に1から10までの和を求めるプログラムを作成する

	
	//// 結果を出力する
	printf( "合計は 55 です\n" );

	return 0;
}
