#include<stdio.h>
int main()
{
	int i;
	scanf("%d",&i);
	printf("Hey!\n"); 
	return 0
}