﻿<?PHP
	include '../Server.php';
	$Server = new Server();
?>
<?PHP
session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: ../Destory.php");
	exit;
}
if(isset($_POST['runstart'])){
	$FPATH2Prg = '/home/tto/public_html/kadai/complete_box/'.$_SESSION['USERID'].'/12/12.txt';
	$text = htmlspecialchars( $_POST["TextArea1"] );
	echo 'PASS:'.$FPATH2Prg.'<br/>';
		
	if(!$fp = fopen($FPATH2Prg,'wb')){
		echo 'ファイルオープン失敗';
		exit();
	}
	$text = html_entity_decode($text, ENT_QUOTES);
	if($result = fwrite($fp, $text."\n")){
		fclose($fp);
		header("Location: ../compile_execute_result.php?no=12");
		exit();
	}
	else{
		echo '書き込み失敗';
	}
}
else if(isset($_POST['faq'])){
	header("Location: ../faq.php?KNo=12");
	exit();
}
else if(isset($_POST['throws'])){
	//提出時の動作
	$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
	if($mysqli->connect_error){
		//CONNECT FAILURE
		echo "<p>CONNECT FAILURE</p>";
	}
	else{
		$mysqli->set_charset("utf8");
	}
	$times=date('Y-m-d');
	$sql1 = "UPDATE teisyutsu SET joutai = '0' AND date='".$times."' WHERE fk_id_user ='".$_SESSION['USERID']."' AND fk_id_kadai = '12'";
	$result1 = $mysqli->query($sql1);
	if(!$result1){
		echo '<p>Query is FAILURED.</p>'. $mysqli_error;
		exit();
	}
	$sql2= "INSERT INTO teisyutsu (fk_id_user, fk_id_kadai, joutai) VALUES ('".$_SESSION['USERID']."', '13', '-')";
	$mysqli->query($sql2);
	$mysqli->close();
	header("Location: ../menu.php");
	exit;
}
else{
	
}
?>
<!DOCTYPE html>
<html>

<head>
	<meta content="ja" http-equiv="Content-Language" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<meta http-equiv="x-ua-compatible" content="IE=10">
	<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
	<title>
		課題12
	</title>
	<style type="text/css">
		.auto-style1 {
			text-align: right;
		}
		.auto-style2 {
			font-size: medium;
		}
		.auto-style5 {
			text-align: center;
		}
		.auto-style10 {
			text-align: left;
		}
		.auto-style11 {
			text-align: left;
			font-size: larger;
		}
		.auto-style12 {
			text-align: center;
			font-size: x-large;
			font-family: "Arial Black";
		}
		.auto-style13 {
			font-size: small;
		}
		.auto-style14 {
			text-decoration: underline;
		}
		.auto-style15 {
			margin-left: 40px;
		}
		.auto-style20{
			background-color: #66FFFF;
		}
		.auto-style21{
			width: 100%;
			height:400px;
			font-family: 'Courier New', Courier, monospace;
			font-size: large;
		}
		.auto-style22{
			 width: 100%;
			 height: 41px;
			 z-index: 1;
			 left: 15px;
			 top: 577px;
			 bottom: -69px;
		}
	</style>
	<script type="text/javascript">
	<!--
		function insertTab(o, e){
			var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
			if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey){
				var oS = o.scrollTop;
				if (o.setSelectionRange){
					var sS = o.selectionStart;
					var sE = o.selectionEnd;
					o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
					o.setSelectionRange(sS + 1, sS + 1);
					o.focus();
				}
				else if (o.createTextRange){
					document.selection.createRange().text = "\t";
					e.returnValue = false;
				}
				o.scrollTop = oS;
				if (e.preventDefault){
					e.preventDefault();
				}
				return false;
			}
			return true;
		}//-->
	</script>
</head>

<body>
	<div class="auto-style1">
		[Name:<?=htmlspecialchars($_SESSION["USERName"], ENT_QUOTES); ?>][<a href="../menu.php">Menu</a>]
	</div>
	<hr/>
	<div class="auto-style12">
		<strong>
			課題12：10進数を2進数に変換する Part.3
			<br />
		</strong>
		<span class="auto-style13">
			キーワード：for文,基数変換、2進数、10進数
		</span>
	</div>
	<hr/>
	<form method="post">
		<div class="auto-style5" style="margin-bottom: 2em">
			<fieldset class="auto-style20" name="Group1" style="width: 90%">
				<legend class="auto-style11">
					<strong>
						課題の内容
					</strong>
				</legend>
				<div class="auto-style10">
					<p class="auto-style15">
						<strong>
							<span class="auto-style14">
								for文を使って、10進数の数を入力すると2進数に変換する基数変換の手続きを作成しなさい。
							</span>
						</strong>
					</p>
					<p class="auto-style15">
						<br />
						&emsp;&emsp;ただし、2047を超えた10進数でも対応できるようにしなさい。<br />
						<span class="auto-style14">ヒント：</span><br />
						&emsp;&emsp;変数binを1で初期化し、入力した10進数の値を超えるまで2を掛け、課題11の1024の代わりに使う。<br />
						&emsp;&emsp;★ for文で不要な部分は ; のみで省略できる<br />
						<span class="auto-style14">例：</span><br />
						&emsp;&emsp;初期化が不要の時　　　for ( ; x < 10; x ++ )<br />
						&emsp;&emsp;繰り返し条件のみの時　for ( ; x < 10; )<br />
						&emsp;&emsp;無限に繰り返すとき　　for (;;)	// while ( 1 )も同じ<br />

					</p>
				</div>
			</fieldset>
		</div>
	</form>
	<form method="post">
		<textarea class="auto-style21" name="TextArea1" tabindex="0" cols="20" rows="1" onkeydown="insertTab(this, event);">
#define _CRT_SECURE_NO_WARNINGS  // 余計な警告が出ないようにする
#include	<stdio.h>

int	main( void )
{
	int	dec;	// 変換する10進数
	int	no;		// 現在の桁の数
	int	bin;	// 2進数の現在の桁の値

	printf( "2進数に変換する値を入力してください >" );
	scanf( "%d", &dec );

	//// 以下に10進数を2進数に変換するプログラムを作成する

	return 0;
}</textarea>
		<div class="auto-style22" id="layer1">
			<button class="auto-style2" name="faq" action="kadai12.php">質問</button>　
			<button class="auto-style2" name="runstart" action="kadai12.php">コンパイル・実行</button>　
			<button class="auto-style2" name="throws" action="kadai12.php">提出</button><br />
			<hr/>
			<p class="auto-style5">
				最終更新日：2016.04.01
			</p>
		</div>
	</form>
</body>
</html>