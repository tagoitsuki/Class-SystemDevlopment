<?PHP
	class Server{
		public $url = "localhost";
		public $user = "tto";
		public $dbpass = "nitkambayashi";
		public $dbname = "prog";
	}
?>