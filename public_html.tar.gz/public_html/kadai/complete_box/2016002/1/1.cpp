#include <stdio.h>
int main()
{
	printf("hello nit!");
	return 0;
}