<html><head><title>test</title></head>
<body>
<?php

echo shell_exec('sh dircompile.sh A1_1.txt 1155148 A1-1');

?>
</body>
</html>
