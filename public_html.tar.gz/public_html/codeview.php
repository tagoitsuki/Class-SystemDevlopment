<?PHP
session_start();
//ログイン状態のチェック
if(!isset($_SESSION["USERID"])){
	header("Location: Destory.php");
	exit;
}
?>
<!DOCTYPE html>
<html>

<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
<title>コンパイルしたプログラム</title>
<style type="text/css">
.auto-style1 {
	text-align: right;
}
nav{
	width: 100%; /*横幅の指定*/;
	border-top: 1px solid blue;
/*上部の線の色を指定*/border-bottom: 1px solid blue;
/*下部の線の色を指定*/margin-bottom: 1px; /**/;
	overflow: hidden;   /*おまじない*/
	margin-top: 0px;
}
nav ul{
    width: 125%; /*横幅の指定*/
    list-style-type: none;
}
nav li{
	/*横幅の指定（線の分をマイナスする）*/
	width: 12%;
	border-left: 1px solid blue;  /*線を描く*/
    text-align: center; /*文字を中央に*/
    float: left;    /*左から並べる*/
}
nav li:last-child{
    border-right: 1px solid blue; /*li要素の最後の物は右側に線を描く*/
}
nav a{
    display: block; /*1つのli全体にリンクを有効にする*/
    text-decoration: none;  /*ブラウザ標準のリンク装飾をオフに*/
    color:#313131;  /*文字色の変更*/
    font-size: 110%;    /*フォントサイズの指定*/
    letter-spacing: 5px;    /*文字と文字の間隔をあける*/
    font-weight: 300;   /*文字の太さを調整*/
    line-height: 25px;  /*行間の指定（ナビボタンの高さ指定）*/
}
nav a:hover{
	background-color: blue;   /*背景色の指定*/
	color: #fff; /*文字色の変更*/;
	transition: 0.25s;   /*ホバー時の動きをなめらかにする*/
}
h2 {
	padding: .75em 1em;
	border: 1px solid #ccc;
	border-top: 3px solid #3498db;
	background: -webkit-linear-gradient(top, #fff 0%, #f0f0f0 100%);
	background: linear-gradient(to bottom, #fff 0%, #f0f0f0 100%);
	box-shadow: 0 -1px 0 rgba(255, 255, 255, 1) inset;
}
</style>
	<script type="text/javascript" src="scripts/shCore.js"></script>
	<script type="text/javascript" src="scripts/shBrushCpp.js"></script>
	<link type="text/css" rel="stylesheet" href="styles/shCoreDefault.css"/>
	<script type="text/javascript">SyntaxHighlighter.all();</script>
</head>
<body style="background: white;">
<div class="auto-style1">
	ID:<?=htmlspecialchars($_SESSION["USERID"], ENT_QUOTES); ?>/ようこそ、<?=htmlspecialchars($_SESSION["USERName"], ENT_QUOTES); ?>さん！
</div>
<nav><ul>
<li><a href="https://www.youtube.com/channel/UCOLHDVyHEmX9m-0bsocEFzA" target="_blank">解説動画</a></li>
<li><a href="faq.php?KNo=">質問</a></li>
<li><a href="pass_change.php">パスワード変更</a></li>
<li><a href="show.php">情報表示</a></li>
<li><a href="menu.php">もどる</a></li>
<li><a href="Destory.php">ログアウト</a></li>
</ul>
</nav>
<h2>プログラムコード表示</h2>
<form action="" method="post">
<div>このシステムの中に保存されているプログラムを表示することができます。コンパイル・実行を押した課題のみ表示できます。</div>
	課題番号：<input name="Text1" type="text">&emsp;
	<button name="Abutton1">表示する</button></form>
	<pre class="brush: cpp;">
<?PHP
	if(isset($_POST['Abutton1'])){
		if($fp = fopen("kadai/complete_box/".$_SESSION['USERID']."/".$_POST['Text1']."/".$_POST['Text1'].".cpp", 'r')){
			// whileで行末までループ処理
			while (!feof($fp)) {
				// fgetssでファイルを読み込み、変数に格納
				$txt = fgetss($fp);
				// ファイルを読み込んだ変数を出力
				echo $txt;
			}
			// fcloseでファイルを閉じる
			fclose($fp);
		}
		else{
			echo 'File not found';
		}
	}
?>
</pre>
</body>

</html>
