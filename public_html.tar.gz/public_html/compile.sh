#! /bin/sh

##別ディレクトリを指定するのができねえ…でもコンパイルできてたっぽいし、実行の問題？

## 第1引数 ファイル名 第2 学籍 第3 課題番号 を想定
## 増えるなら -ne 4( != 4)とかにする
if [ "$#" -ne 3 ]; then
  echo "引数は3つです。引数1:ファイル名 2:学籍番号 3:課題番号"
  exit 1
fi

## 直パスで指定して、ディレクトリに移動。
## ディレクトリは事前に作るべし？

dir= `echo "/home/tto/public_html/kadai/complete_box/${2}/${3}"`
pushd `dirname $0` > ${dir}
#cd ${dir}

## ファイル名・拡張子の取り出し
fps=`echo $(basename ${dir}/${1})`
fnm=`echo ${fps%%.*}`

## .cppへの拡張子変換
## エラーがあってもデバッグテキストに書き込むので表示されない、割と正常に動く
cp ${fps} ${fnm}.cpp 2> debug.txt
if [ -s debug.txt ]; then
  echo `cat debug.txt`
fi
## コンパイル
g++ ${fnm}.cpp -o ${fnm} 2> debug.txt

if [ -s debug.txt ]; then
  echo `cat debug.txt`
fi
if [ -e ${fnm} ]; then
  ## 実行、実行ファイルを消す
  ./${fnm} #; rm ./${fnm}
else
  echo "実行失敗"
fi
popd > /dev/null
##←シェルにおけるコメント
## $#：引数の数  $1：引数の一つ目 2,3,...{10},{11}...
## ${…}：文字と識別されないために変数名の範囲を明示
## -s：文字の数を調べる  -ne：!=の意。比較演算子が特殊
## basename：パスからディレクトリを除いてファイル名を取得するコマンド
## ${変数%%.*}：拡張子の削除を行う(パラメータ展開)
## `echo ~~`  ``：コマンドを評価。今回はechoで表示される文字列を格納
## gcc ... 2> 2：標準エラー出力  >：ファイルに上書き(>>：下に追加)
