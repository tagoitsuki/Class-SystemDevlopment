#!/bin/bash

${1}