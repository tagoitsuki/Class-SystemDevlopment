<?PHP
	class Server{
		public $url = "localhost";
		public $user = "root";
		public $dbpass = "21tago82";
		public $dbname = "prg";
	}
?>