﻿<!DOCTYPE html>
<html>

<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
<title>送信完了しました</title>
<style type="text/css">
.auto-style1 {
	color: #FFFFFF;
	font-size: x-large;
	background-color: #0000FF;
}
</style>
</head>

<body>
<div class="auto-style1" style="width: 100%"><strong><em>質問フォーム　-＞送信完了しました。</em></strong></div>
<div></div>
<div>質問ID:<label id="faqID"></label></div>
<form><input name="Button1" type="submit" value="Menuへもどる" formaction="menu.php"/></form>
</body>

</html>
