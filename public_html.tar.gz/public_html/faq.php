﻿<?PHP
	include 'Server.php';
	$Server = new Server();
	
	$mysqli = new mysqli($Server->url, $Server->user, $Server->dbpass, $Server->dbname);
	
	if($mysqli->connect_error){
		//CONNECT FAILURE
		echo '<strong>▼Notice</strong><br/>CONNECT FAILURED';
	}
	else{
		$mysqli->set_charset("utf8");
	}
	if(isset($_POST['Abutton1'])){
		$sqlc = "SELECT * FROM kadai WHERE kadai_name='".$_POST['Text1']."'";
		$res = $mysqli->query($sqlc);
		if($res){
			while($row = $res->fetch_assoc()){
				$id = $row["id_kadai"];
			}
		}
		$sql = "UPDATE teisyutsu SET cmnt_user='".$_POST['TextArea1']."' WHERE fk_id_user='".$_SESSION['USERID']."' AND fk_id_kadai='".$id."'";
		$result = $mysqli->query($sql);
		if(!$result){
			echo '<strong>▼Notice</strong><br/>Query is FAILURED'. $mysqli_error;
			exit();
		}
		header("Location: faq_conp.php");
		exit();
	}
	
	if(isset($_GET['Abutton2'])){
		header("Location: menu.php");
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="ja" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta http-equiv="x-ua-compatible" content="IE=10">
<meta http-equiv="x-ua-compatible" content="IE=Emulate10">
	<title>質問フォーム</title>
	<style type="text/css">
		.auto-style2 {
			text-align: right;
		}
	.auto-style3 {
	color: #FFFFFF;
	font-size: x-large;
	background-color: #0000FF;
}
	</style>
	<script type="text/javascript">
	<!--
		function insertTab(o, e){
			var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
			if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey){
				var oS = o.scrollTop;
				if (o.setSelectionRange){
					var sS = o.selectionStart;
					var sE = o.selectionEnd;
					o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
					o.setSelectionRange(sS + 1, sS + 1);
					o.focus();
				}
				else if (o.createTextRange){
					document.selection.createRange().text = "\t";
					e.returnValue = false;
				}
				o.scrollTop = oS;
				if (e.preventDefault){
					e.preventDefault();
				}
				return false;
			}
			return true;
		}//-->
	</script>
</head>

<body>
	<div class="auto-style3" style="width: 100%"><strong><em>質問フォーム　-＞質問内容を入力してください</em></strong></div>
	<div>
		<form method="post">
			課題番号：<input name="Text1" type="text"
			<?PHP
				if($_GET['KNo']!=NULL) echo 'readonly="true" value="'.$_GET['KNo'].'"';
			?>/>
			<br />
		<br />
			<strong>質問内容：</strong><br/>
		<textarea cols="20" name="TextArea1" style="width: 100%; height: 200px; font-size: large;" onkeydown="insertTab(this, event);"></textarea>
			<div class="auto-style2">
				<button name="Abutton1" type="submit" action="faq.php">質問を送ります！</button>&nbsp;
				<button name="Abutton2" type="submit" action="faq.php">やっぱ投稿しない</button></div>
		</form>
	</div>
</body>
</html>
