#include<stdio.h>

int main()
{
  printf("Hey!");
  return 0;

