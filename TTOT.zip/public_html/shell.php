<html><head><title>test</title></head>
<body>
<?php

$out = shell_exec("sh ./hello2.sh");
echo $out;
?>
</body>
</html>
