﻿<!DOCTYPE html>
<html>

<head>
<meta content="ja" http-equiv="Content-Language">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>UserID or Password Error</title>
<style type="text/css">
.auto-style1 {
	text-align: center;
	font-size: xx-large;
	font-family: Candara;
	background-color: #FF0000;
}
.auto-style2 {
	color: #FFFFFF;
	background-color: #FF0000;
}
.auto-style3 {
	text-align: center;
}
.auto-style4 {
	background-color: #FF0000;
}
</style>
</head>

<body>

<div class="auto-style1">
	<strong><span class="auto-style2"><em>UserID or Password Error!</em></span></strong></div>
<div class="auto-style3">
	<br>入力されたUserIDまたはパスワードが間違っています。<br></div>
<div class="auto-style4">
</div>
<form method="post">
	<div class="auto-style3">
		<button name="Abutton1" type="submit" formaction="LOGIN.php">もどる</button></div>
</form>

</body>

</html>
