﻿<!DOCTYPE html html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>送信完了しました</title>
<style type="text/css">
.auto-style1 {
	color: #FFFFFF;
	font-size: x-large;
	background-color: #0000FF;
}
</style>
</head>

<body>
<div class="auto-style1" style="width: 100%"><strong><em>質問フォーム　-＞送信完了しました。</em></strong></div>
<div></div>
<div>質問ID:<label id="faqID"></label></div>
<form><input name="Button1" type="submit" value="Menuへもどる" formaction="menu.html"/></form>
</body>

</html>
